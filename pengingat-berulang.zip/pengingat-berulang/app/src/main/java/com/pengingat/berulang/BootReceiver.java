package com.pengingat.berulang;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Alarm terhapus saat HP dimatikan. Receiver ini memasangnya kembali setelah
 * HP menyala, setelah jam/zona waktu diubah, dan setelah aplikasi diperbarui.
 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Pengingat.jadwalUlang(context);
    }
}
