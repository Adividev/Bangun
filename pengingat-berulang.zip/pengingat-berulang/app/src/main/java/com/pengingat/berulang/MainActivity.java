package com.pengingat.berulang;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;

public class MainActivity extends Activity {

    private static final int MINTA_IZIN = 10;
    private static final String IZIN_NOTIF = "android.permission.POST_NOTIFICATIONS";
    private static final long MAKS_MENIT = 7L * 24L * 60L; // 7 hari

    private EditText isiJam;
    private EditText isiMenit;
    private EditText isiTeks;
    private Button tombolMulai;
    private Button tombolBerhenti;
    private Button tombolSuara;
    private Button tombolBaterai;
    private TextView status;

    private long intervalDipilih;
    private String teksDipilih;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable segarkan = new Runnable() {
        @Override
        public void run() {
            perbaruiTampilan();
            handler.postDelayed(this, 5000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        isiJam = findViewById(R.id.isi_jam);
        isiMenit = findViewById(R.id.isi_menit);
        isiTeks = findViewById(R.id.isi_teks);
        tombolMulai = findViewById(R.id.tombol_mulai);
        tombolBerhenti = findViewById(R.id.tombol_berhenti);
        tombolSuara = findViewById(R.id.tombol_suara);
        tombolBaterai = findViewById(R.id.tombol_baterai);
        status = findViewById(R.id.status);

        // Isi kolom dengan pengaturan terakhir.
        long totalMenit = Pengingat.intervalMs(this) / 60000L;
        isiJam.setText(String.valueOf(totalMenit / 60L));
        isiMenit.setText(String.valueOf(totalMenit % 60L));
        SharedPreferences p = Pengingat.pref(this);
        isiTeks.setText(p.getString("teks", ""));

        tombolMulai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tekanMulai();
            }
        });
        tombolBerhenti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Pengingat.berhenti(MainActivity.this);
                perbaruiTampilan();
            }
        });
        tombolSuara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bukaPengaturanSuara();
            }
        });
        tombolBaterai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mintaBebasHematBaterai();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Jika alarm sempat hilang (mis. aplikasi dipaksa berhenti), pasang lagi.
        if (Pengingat.aktif(this)
                && Pengingat.berikutPada(this) < System.currentTimeMillis() - 5000L) {
            Pengingat.jadwalUlang(this);
        }
        handler.removeCallbacks(segarkan);
        handler.post(segarkan);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(segarkan);
    }

    private static long angka(EditText e) {
        String s = e.getText().toString().trim();
        if (s.isEmpty()) {
            return 0L;
        }
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException ex) {
            return -1L;
        }
    }

    private void tekanMulai() {
        long jam = angka(isiJam);
        long menit = angka(isiMenit);
        if (jam < 0 || menit < 0) {
            pesan("Jam dan menit harus berupa angka.");
            return;
        }
        long totalMenit = jam * 60L + menit;
        if (totalMenit < 1) {
            pesan("Isi interval minimal 1 menit.");
            return;
        }
        if (totalMenit > MAKS_MENIT) {
            pesan("Interval paling lama 7 hari.");
            return;
        }
        intervalDipilih = totalMenit * 60000L;
        teksDipilih = isiTeks.getText().toString().trim();
        if (teksDipilih.isEmpty()) {
            teksDipilih = Pengingat.TEKS_BAWAAN;
        }

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(IZIN_NOTIF) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {IZIN_NOTIF}, MINTA_IZIN);
            return;
        }
        jalankan();
    }

    @Override
    public void onRequestPermissionsResult(int kode, String[] izin, int[] hasil) {
        super.onRequestPermissionsResult(kode, izin, hasil);
        if (kode != MINTA_IZIN) {
            return;
        }
        if (hasil.length > 0 && hasil[0] == PackageManager.PERMISSION_GRANTED) {
            jalankan();
        } else {
            pesan("Izin notifikasi diperlukan. Aktifkan dulu, lalu tekan Mulai lagi.");
            bukaPengaturanNotifikasi();
        }
    }

    private void jalankan() {
        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 24 && nm != null && !nm.areNotificationsEnabled()) {
            pesan("Notifikasi aplikasi ini dimatikan. Aktifkan dulu, lalu tekan Mulai lagi.");
            bukaPengaturanNotifikasi();
            return;
        }
        if (intervalDipilih < 60000L) {
            return;
        }
        Pengingat.mulai(this, intervalDipilih, teksDipilih);
        pesan("Pengingat dimulai: tiap " + Pengingat.sebutInterval(intervalDipilih) + ".");
        perbaruiTampilan();
    }

    private void perbaruiTampilan() {
        boolean aktif = Pengingat.aktif(this);
        if (aktif) {
            String jam = DateFormat.getTimeFormat(this)
                    .format(new Date(Pengingat.berikutPada(this)));
            status.setText("AKTIF — tiap " + Pengingat.sebutInterval(Pengingat.intervalMs(this))
                    + "\nNotifikasi berikutnya pukul " + jam);
            status.setBackgroundResource(R.drawable.kartu_aktif);
        } else {
            status.setText("Tidak aktif\nAtur interval, lalu tekan Mulai.");
            status.setBackgroundResource(R.drawable.kartu);
        }
        isiJam.setEnabled(!aktif);
        isiMenit.setEnabled(!aktif);
        isiTeks.setEnabled(!aktif);
        tombolMulai.setEnabled(!aktif);
        tombolBerhenti.setEnabled(aktif);

        tombolSuara.setVisibility(Build.VERSION.SDK_INT >= 26 ? View.VISIBLE : View.GONE);

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean sudahBebas = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        tombolBaterai.setVisibility(sudahBebas ? View.GONE : View.VISIBLE);
    }

    private void bukaPengaturanNotifikasi() {
        Intent i;
        if (Build.VERSION.SDK_INT >= 26) {
            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        } else {
            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
        }
        buka(i);
    }

    private void bukaPengaturanSuara() {
        if (Build.VERSION.SDK_INT < 26) {
            return;
        }
        Pengingat.buatKanal(this);
        Intent i = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())
                .putExtra(Settings.EXTRA_CHANNEL_ID, Pengingat.KANAL);
        if (!buka(i)) {
            bukaPengaturanNotifikasi();
        }
    }

    private void mintaBebasHematBaterai() {
        Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:" + getPackageName()));
        if (!buka(i)) {
            buka(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    private boolean buka(Intent i) {
        try {
            startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void pesan(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
