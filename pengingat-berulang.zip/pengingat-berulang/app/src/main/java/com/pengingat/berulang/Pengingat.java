package com.pengingat.berulang;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;

/** Inti aplikasi: menyimpan pengaturan, memasang alarm, dan menampilkan notifikasi. */
final class Pengingat {

    static final String AKSI_BUNYI = "com.pengingat.berulang.BUNYI";
    static final String AKSI_BERHENTI = "com.pengingat.berulang.BERHENTI";
    static final String KANAL = "pengingat_v1";
    static final int ID_NOTIF = 1;
    static final String TEKS_BAWAAN = "Waktunya pengingat!";

    private static final String PREF = "pengingat";
    private static final String K_AKTIF = "aktif";
    private static final String K_INTERVAL = "intervalMs";
    private static final String K_TEKS = "teks";
    private static final String K_MULAI = "mulaiPada";
    private static final String K_BERIKUT = "berikutPada";

    private Pengingat() {}

    static SharedPreferences pref(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    static boolean aktif(Context c) {
        return pref(c).getBoolean(K_AKTIF, false);
    }

    static long intervalMs(Context c) {
        return pref(c).getLong(K_INTERVAL, 30L * 60000L);
    }

    static String teks(Context c) {
        return pref(c).getString(K_TEKS, TEKS_BAWAAN);
    }

    static long berikutPada(Context c) {
        return pref(c).getLong(K_BERIKUT, 0L);
    }

    /** Mulai siklus baru, dihitung dari saat ini. */
    static void mulai(Context c, long intervalMs, String teks) {
        long kini = System.currentTimeMillis();
        long berikut = kini + intervalMs;
        pref(c).edit()
                .putBoolean(K_AKTIF, true)
                .putLong(K_INTERVAL, intervalMs)
                .putString(K_TEKS, teks)
                .putLong(K_MULAI, kini)
                .putLong(K_BERIKUT, berikut)
                .apply();
        buatKanal(c);
        pasangAlarm(c, berikut);
    }

    /** Hentikan siklus dan hapus notifikasi yang masih tampil. */
    static void berhenti(Context c) {
        pref(c).edit().putBoolean(K_AKTIF, false).apply();
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            am.cancel(intentBunyi(c));
        }
        NotificationManager nm =
                (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.cancel(ID_NOTIF);
        }
    }

    /**
     * Pasang alarm untuk siklus berikutnya. Dipakai setelah notifikasi berbunyi,
     * setelah HP di-restart, dan setelah jam diubah. Jadwal tetap mengikuti
     * siklus awal (mis. tiap 30 menit sejak tombol Mulai ditekan).
     */
    static void jadwalUlang(Context c) {
        if (!aktif(c)) {
            return;
        }
        SharedPreferences p = pref(c);
        long interval = Math.max(60000L, p.getLong(K_INTERVAL, 30L * 60000L));
        long mulai = p.getLong(K_MULAI, 0L);
        long kini = System.currentTimeMillis();
        long berikut;
        if (mulai <= 0L || kini < mulai) {
            // Jam HP dimundurkan: mulai siklus baru dari sekarang.
            mulai = kini;
            berikut = kini + interval;
        } else {
            long putaran = (kini - mulai) / interval + 1L;
            berikut = mulai + putaran * interval;
        }
        p.edit().putLong(K_MULAI, mulai).putLong(K_BERIKUT, berikut).apply();
        pasangAlarm(c, berikut);
    }

    private static PendingIntent intentBunyi(Context c) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(AKSI_BUNYI);
        return PendingIntent.getBroadcast(c, 1, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent intentBuka(Context c) {
        Intent i = new Intent(c, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void pasangAlarm(Context c, long pada) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) {
            return;
        }
        PendingIntent bunyi = intentBunyi(c);
        boolean bolehTepat = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        if (bolehTepat) {
            try {
                // Jenis alarm jam: tetap tepat waktu walau layar mati / mode hemat daya.
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(pada, intentBuka(c)), bunyi);
                return;
            } catch (SecurityException e) {
                // lanjut ke cadangan di bawah
            }
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, pada, bunyi);
    }

    static void buatKanal(Context c) {
        if (Build.VERSION.SDK_INT < 26) {
            return;
        }
        NotificationManager nm =
                (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(KANAL) != null) {
            return;
        }
        NotificationChannel k = new NotificationChannel(
                KANAL, "Pengingat", NotificationManager.IMPORTANCE_HIGH);
        k.setDescription("Notifikasi pengingat berulang");
        k.enableVibration(true);
        k.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        k.setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build());
        nm.createNotificationChannel(k);
    }

    @SuppressWarnings("deprecation")
    static void tampilkanNotifikasi(Context c) {
        NotificationManager nm =
                (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) {
            return;
        }
        buatKanal(c);

        String teks = teks(c);
        if (teks == null || teks.trim().isEmpty()) {
            teks = TEKS_BAWAAN;
        }

        Intent stop = new Intent(c, AlarmReceiver.class).setAction(AKSI_BERHENTI);
        PendingIntent piStop = PendingIntent.getBroadcast(c, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new Notification.Builder(c, KANAL);
        } else {
            b = new Notification.Builder(c);
            b.setPriority(Notification.PRIORITY_HIGH);
            b.setDefaults(Notification.DEFAULT_ALL);
        }
        b.setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Pengingat")
                .setContentText(teks)
                .setStyle(new Notification.BigTextStyle().bigText(teks))
                .setColor(c.getResources().getColor(R.color.utama))
                .setCategory(Notification.CATEGORY_REMINDER)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true)
                .setAutoCancel(true)
                .setContentIntent(intentBuka(c))
                .addAction(R.drawable.ic_notif, "Berhenti", piStop);

        try {
            nm.notify(ID_NOTIF, b.build());
        } catch (SecurityException e) {
            // izin notifikasi dicabut: abaikan, siklus tetap berjalan
        }
    }

    /** Contoh hasil: "30 menit", "2 jam", "1 jam 30 menit". */
    static String sebutInterval(long intervalMs) {
        long totalMenit = intervalMs / 60000L;
        long jam = totalMenit / 60L;
        long menit = totalMenit % 60L;
        if (jam > 0 && menit > 0) {
            return jam + " jam " + menit + " menit";
        } else if (jam > 0) {
            return jam + " jam";
        }
        return menit + " menit";
    }
}
