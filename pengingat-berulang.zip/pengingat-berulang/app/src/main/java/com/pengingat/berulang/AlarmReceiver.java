package com.pengingat.berulang;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Menerima alarm (waktunya berbunyi) dan tombol Berhenti dari notifikasi. */
public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String aksi = intent == null ? null : intent.getAction();
        if (Pengingat.AKSI_BERHENTI.equals(aksi)) {
            Pengingat.berhenti(context);
        } else if (Pengingat.AKSI_BUNYI.equals(aksi)) {
            if (!Pengingat.aktif(context)) {
                return;
            }
            Pengingat.tampilkanNotifikasi(context);
            Pengingat.jadwalUlang(context);
        }
    }
}
